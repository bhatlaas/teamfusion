﻿$(function () {
    $("input[name='DateOfBirth']").datepicker({
        changeMonth: true,
        changeYear: true,
        showTimepicker: false
    });
});

